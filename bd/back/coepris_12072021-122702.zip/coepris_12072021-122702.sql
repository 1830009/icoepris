-- MariaDB dump 10.19  Distrib 10.4.18-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: coepris
-- ------------------------------------------------------
-- Server version	10.4.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activos`
--

DROP TABLE IF EXISTS `activos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activos` (
  `id_activos` int(11) NOT NULL AUTO_INCREMENT,
  `n_serie` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `cantidad` double NOT NULL,
  `unidad` varchar(50) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_activos`),
  UNIQUE KEY `n_serie` (`n_serie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activos`
--

LOCK TABLES `activos` WRITE;
/*!40000 ALTER TABLE `activos` DISABLE KEYS */;
/*!40000 ALTER TABLE `activos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `archivo`
--

DROP TABLE IF EXISTS `archivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `archivo` (
  `id_archivo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `fecha` date NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `observacion` varchar(300) DEFAULT NULL,
  `aclaracion` int(11) NOT NULL DEFAULT 0,
  `checklist` int(11) DEFAULT 0,
  `coordinacion` varchar(50) NOT NULL DEFAULT 'TODAS',
  `categoria` varchar(50) NOT NULL DEFAULT 'DOCUMENTO',
  PRIMARY KEY (`id_archivo`,`aclaracion`),
  KEY `checklist` (`checklist`),
  CONSTRAINT `archivo_ibfk_1` FOREIGN KEY (`checklist`) REFERENCES `checklist` (`id_check`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archivo`
--

LOCK TABLES `archivo` WRITE;
/*!40000 ALTER TABLE `archivo` DISABLE KEYS */;
INSERT INTO `archivo` VALUES (1,'Netinho','2021-05-22','INGRESO','si',0,1,'TODAS','DOCUMENTO'),(2,'Netinho','2021-05-22','INGRESO','si',0,2,'TODAS','DOCUMENTO'),(4,'Prueba','2021-05-19','ADMINISTRATIVO','sssssss',0,0,'PADILLA','CARPETA'),(7,'00001','2021-07-03','FONDO','ejemplo descripcion',0,0,'CD VICTORIA','FONDO'),(8,'00001','2021-07-03','FONDO','siu',0,0,'TAMPICO','FONDO'),(10,'1','2021-07-12','INGRESO','1',0,8,'TODAS','DOCUMENTO'),(11,'2','2021-07-12','FONDO','3',0,0,'TODAS','FONDO'),(13,'22','2021-07-12','ADMINISTRATIVO','4',1,0,'TODAS','CARPETA');
/*!40000 ALTER TABLE `archivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checklist`
--

DROP TABLE IF EXISTS `checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checklist` (
  `id_check` int(11) NOT NULL AUTO_INCREMENT,
  `boleta` varchar(35) NOT NULL,
  `cotejo` varchar(35) NOT NULL,
  `sistema` varchar(35) NOT NULL,
  `archivado` varchar(35) NOT NULL,
  `disco` varchar(35) NOT NULL,
  `folio` varchar(35) NOT NULL,
  `relacionado` varchar(35) NOT NULL,
  PRIMARY KEY (`id_check`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checklist`
--

LOCK TABLES `checklist` WRITE;
/*!40000 ALTER TABLE `checklist` DISABLE KEYS */;
INSERT INTO `checklist` VALUES (0,'0','0','0','0','0','0','0'),(1,'1,2,3,4,5,6,7,8,9,10,11,12,13','1,2,3,4,5,6,7,8,9,10,11,12,13','0','0','1,2,3,4,5,6,7,8,9,10,11,12,13','1,2,3,4,5,6,7,8,9,10,11,12,13','1,2,3,4,5,6,7,8,9,10,11,12,13'),(2,'1,2,3,4,5,6,7,8,9,10,11,12,13','0','0','11','0','0','0'),(6,'0','0','0','0','0','0','0'),(7,'1,2,3,4,5,6,7,8,9,10,11,12,13','0','0','9','0','0','0'),(8,'1,2,3,4,5,6,7,8,9,10,11,12,13','0','0','0','0','0','0'),(9,'0','0','0','0','0','0','0');
/*!40000 ALTER TABLE `checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donacion`
--

DROP TABLE IF EXISTS `donacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donacion` (
  `id_donacion` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `cantidad` double NOT NULL,
  `tabla` varchar(50) NOT NULL,
  PRIMARY KEY (`id_donacion`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donacion`
--

LOCK TABLES `donacion` WRITE;
/*!40000 ALTER TABLE `donacion` DISABLE KEYS */;
INSERT INTO `donacion` VALUES (1,'5',3,'papeleria'),(2,'1',9,'papeleria'),(7,'2',1,'papeleria'),(8,'3',1,'papeleria');
/*!40000 ALTER TABLE `donacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleado` (
  `id_empleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido_pat` varchar(50) NOT NULL,
  `apellido_mat` varchar(50) NOT NULL,
  `rfc` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_empleado`),
  UNIQUE KEY `rfc` (`rfc`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (1,'root','root','root','rooot','root@root.com','1111111111'),(5,'Miguel','Puente','Carrizal','RFC','miguelpuente@hotmail.com','8312039283');
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fecha_entrada`
--

DROP TABLE IF EXISTS `fecha_entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fecha_entrada` (
  `id_entrada` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cantidad` int(11) NOT NULL,
  `tabla` varchar(50) NOT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_entrada`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `fecha_entrada_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fecha_entrada`
--

LOCK TABLES `fecha_entrada` WRITE;
/*!40000 ALTER TABLE `fecha_entrada` DISABLE KEYS */;
/*!40000 ALTER TABLE `fecha_entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fecha_salida`
--

DROP TABLE IF EXISTS `fecha_salida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fecha_salida` (
  `id_salida` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cantidad` int(11) NOT NULL,
  `tabla` varchar(50) NOT NULL,
  `empleado` varchar(100) NOT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_salida`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `fecha_salida_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fecha_salida`
--

LOCK TABLES `fecha_salida` WRITE;
/*!40000 ALTER TABLE `fecha_salida` DISABLE KEYS */;
/*!40000 ALTER TABLE `fecha_salida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formato`
--

DROP TABLE IF EXISTS `formato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formato` (
  `id_formato` int(11) NOT NULL,
  `logo_header` varchar(200) NOT NULL,
  `logo_footer` varchar(200) NOT NULL,
  `color` varchar(20) NOT NULL,
  `autorizo` varchar(200) NOT NULL,
  `vobo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formato`
--

LOCK TABLES `formato` WRITE;
/*!40000 ALTER TABLE `formato` DISABLE KEYS */;
INSERT INTO `formato` VALUES (0,'img/logo-coepris.png','img/coepris.png','0,100,167','Lic. Miguel Puente','Lic. Ernesto');
/*!40000 ALTER TABLE `formato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `in_estado`
--

DROP TABLE IF EXISTS `in_estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_estado` (
  `id_entrada` int(11) NOT NULL AUTO_INCREMENT,
  `folio` varchar(20) NOT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad_solicitada` int(11) NOT NULL,
  `cant_surtida` int(11) NOT NULL,
  `cant_recibida` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `observacion` varchar(255) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_entrada`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `in_estado_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`),
  CONSTRAINT `in_estado_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `recurso_estado` (`id_estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `in_estado`
--

LOCK TABLES `in_estado` WRITE;
/*!40000 ALTER TABLE `in_estado` DISABLE KEYS */;
/*!40000 ALTER TABLE `in_estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `in_federal`
--

DROP TABLE IF EXISTS `in_federal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_federal` (
  `id_entrada` int(11) NOT NULL AUTO_INCREMENT,
  `folio` varchar(20) NOT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad_solicitada` int(11) NOT NULL,
  `cant_surtida` int(11) NOT NULL,
  `cant_recibida` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `observacion` varchar(255) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_entrada`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `in_federal_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`),
  CONSTRAINT `in_federal_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `proyecto_federal` (`id_federal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `in_federal`
--

LOCK TABLES `in_federal` WRITE;
/*!40000 ALTER TABLE `in_federal` DISABLE KEYS */;
/*!40000 ALTER TABLE `in_federal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `in_papeleria`
--

DROP TABLE IF EXISTS `in_papeleria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `in_papeleria` (
  `id_entrada` int(11) NOT NULL AUTO_INCREMENT,
  `folio` varchar(20) NOT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad_solicitada` int(11) NOT NULL,
  `cant_surtida` int(11) NOT NULL,
  `cant_recibida` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `observacion` varchar(255) NOT NULL,
  PRIMARY KEY (`id_entrada`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `in_papeleria_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`),
  CONSTRAINT `in_papeleria_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `papeleria` (`id_papeleria`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `in_papeleria`
--

LOCK TABLES `in_papeleria` WRITE;
/*!40000 ALTER TABLE `in_papeleria` DISABLE KEYS */;
INSERT INTO `in_papeleria` VALUES (39,'43132',61,4,4,4,5,''),(40,'43132',62,6,6,6,5,''),(41,'43132',63,5,5,5,5,''),(42,'43132',64,5,5,5,5,'');
/*!40000 ALTER TABLE `in_papeleria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `limpieza`
--

DROP TABLE IF EXISTS `limpieza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `limpieza` (
  `id_limpieza` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `cantidad` double NOT NULL,
  `unidad` varchar(50) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_limpieza`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `limpieza`
--

LOCK TABLES `limpieza` WRITE;
/*!40000 ALTER TABLE `limpieza` DISABLE KEYS */;
INSERT INTO `limpieza` VALUES (1,'prueba1','trapiador',5,'PZA','acme','Amarillo');
/*!40000 ALTER TABLE `limpieza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id_login` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_login`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `login_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'root-coepris_vic','$2y$10$YtZLc5GQRU09Uu9eKzzC0.IeIZ7BL6CiEHW3kNZIMCkbM1BmXEJ9a','root',1),(6,'miguel_admin','$2y$10$9XqX4x1zHy2s5gDJ4g3u5e2GBzSrDu7BNvHc/sZ5mFxxwkG9pFi1i','admin',5);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papeleria`
--

DROP TABLE IF EXISTS `papeleria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `papeleria` (
  `id_papeleria` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `cantidad` double NOT NULL,
  `unidad` varchar(50) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_papeleria`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papeleria`
--

LOCK TABLES `papeleria` WRITE;
/*!40000 ALTER TABLE `papeleria` DISABLE KEYS */;
INSERT INTO `papeleria` VALUES (6,'100005765','PAPEL BOND T/CARTA DE 500H.',0,'PAQ','',''),(7,'100005771','PAPEL BOND T/OFICIO DE 500H.',0,'PAQ','',''),(8,'100004657','LAPIZ ADHESIVO 42GRS.',0,'PZA',' ',''),(9,'100001986','SUJETA DOCUMENTOS 32MM C/12 PZAS',0,'CJ','',''),(11,'100001986_1','SUJETA DOCUMENTOS 50MM C/12 PZAS',0,'PZA',' ',''),(12,'100005862','TIJERAS DE ACERO INOXIDABLE 17.8CM',0,'PZA','',''),(13,'SN-1','MEMORIA 16 GB DRIVER UV220',0,'PZA','',''),(14,'100000127','LAPICERO',0,'PZA','',''),(15,'100002688','CORRECTOR DE CINTA DE 8 X 42MM',0,'PZA','',''),(16,'100005680','GOMA DE MIGAJON M-20 C/20 PZA',0,'CJ','',''),(17,'100005640','ENGRAPADORA TIRA COMPLETA',0,'PZA','',''),(18,'100005766','PAPEL BOND T/CARTA ',0,'PZA','',''),(19,'100000016','COJIN PARA CELLO ',0,'PZA','',''),(20,'100005670','FOLDER T/CARTA CON 100 PZA',0,'PAQ','',''),(23,'100005809','REGISTRADORES T/C',0,'PZA','','VERDE'),(24,'100005807','PUNTILLAS 5MM 10TUBOS 12C/U',0,'CJ','',''),(25,'100005823','SACAPUNTAS MANUAL',0,'PZA','',''),(26,'100004858','NOTAS ADHERIBLESCON 400HJS 78 X 76MM',0,'PAQ',' ',''),(27,'100005693','LAPIZ DE MADERA N2 CON 72P MAS 6 CHARPIN',0,'CJ','',''),(28,'100005679','GOMA DE MIGAJON M-20',0,'PZA','',''),(29,'100000136','PAPEL OPALINA PAQ 100HJAS',0,'PAQ','',''),(30,'100000121','TINTA PARA SELLO',0,'PZA','',''),(31,'100005617','CUADERNO MEDIDA CARTA DE 100HJS',0,'PZA','',''),(32,'100000143','CINTA CANELA DE 48 X 50MTS',0,'PZA','',''),(33,'100005543','CERA CUENTA FACIL 14GRS',0,'PZA','',''),(34,'100005551','CHAROLA FR 3 NIVELES TAMAÑO OFICIO',0,'PZA','',''),(35,'100005692','LAPIZ DE MADERA PAQ 12PZAS',0,'PAQ','',''),(36,'100005498','BANDERITAS AUTOADHERIBLES 3M 683-5CF',0,'PAQ','',''),(37,'10000051','MARCADORES FINO PERMANENTE C/N',0,'PZA','',''),(38,'100005513','CAJA PARA ARCHIVO CARTON TAMAÑO O.',0,'PZA','',''),(39,'100000111','PAPEL KRAFT DE 125CM ANCHO 90GRS.',0,'PZA','',''),(40,'SN_10','ESTRASA (ROLLO)',0,'PZA','',''),(41,'100005685','LAPIZ DE MADERA BICOLOR ',0,'PZA','','BICOLOR'),(43,'100000075','CALCULADORA DE 12 DIGITOS',0,'PZA','',''),(44,'100005525','CARTAPACIO TAMAÑO CARTA A/D DE 3\"',0,'PZA','',''),(45,'100005524','CARTAPACIO TAMAÑO CARTA A/D DE 2\"',0,'PZA','',''),(47,'100005527','CARTAPACIO TAMAÑO CARTA A/D DE 5\"',0,'PZA','',''),(48,'100005561','CINTA ADHESIVA T/24ML X 65 TRANSPARENTE',0,'PZA','',''),(49,'100008134','CINTA MASKING 2\" 48MM X 50MTS',0,'PZA','',''),(50,'100000020','DESGRAPADORA',0,'PZA','',''),(51,'100000022','GRAPA',0,'CJ','',''),(52,'100005698','LIGA AGUILA N18 C/100GMS',0,'CJ','',''),(53,'100011076','MARCADOR P/PINTADOR C/4',0,'PAQ','',''),(54,'100005707','MARCA TEXTOS GRUESO',0,'PZA','','AMARILLO'),(55,'100005707_1','MARCA TEXTOS GRUESO',0,'PZA','','VERDE'),(56,'100005504','BOLIGRAFO P/FINO DIAMANTE ',0,'CJ','','AZUL'),(57,'100005504_1','BOLIGRAFO P/FINO DIAMANTE ',0,'CJ','','NEGRO'),(58,'100010599','PLUMA PUNTO MEDIANO ',0,'PZA','','AZUL'),(59,'100004659','SEPARADOR 2 DIVISIONES ',0,'PAQ','',''),(60,'100000038','TABLA REGISTRADORA C/CLIP SUJETADOR ',0,'PZA','',''),(61,'100017058','TONER HP 202A CF500A ',0,'PZA','HP','NEGRO'),(62,'100017059','TONER HP 202A CF501A',0,'PZA','HP','CYAN'),(63,'100017060','TONER HP 202A CF502A ',0,'PZA','HP','AMARILLO'),(64,'100017061','TONER HP 202A CF503A ',0,'PZA','HP','MAGENTA ');
/*!40000 ALTER TABLE `papeleria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_federal`
--

DROP TABLE IF EXISTS `proyecto_federal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_federal` (
  `id_federal` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `cantidad` double NOT NULL,
  `unidad` varchar(50) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_federal`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_federal`
--

LOCK TABLES `proyecto_federal` WRITE;
/*!40000 ALTER TABLE `proyecto_federal` DISABLE KEYS */;
INSERT INTO `proyecto_federal` VALUES (1,'100018754','PASTILLA DPD PCLORO',0,'PZA','',''),(2,'D999,999,9472.00','FRASCO BOCA ANCHA 1000 ML',0,'PZA','',''),(3,'100006278','HIELERA DE UNICEL DE 19.7 LTS',0,'PZA','',''),(4,'100000302','GEL ANTIBACTERIAL 60 ML',0,'PZA','',''),(5,'D999,999,8927.00','COMPARADORES COLORIMETRICO',0,'PZA','',''),(6,'D999,999,8929.00','FRASCO COLOIDAL DE 30 ML',0,'PZA','','');
/*!40000 ALTER TABLE `proyecto_federal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurso_estado`
--

DROP TABLE IF EXISTS `recurso_estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recurso_estado` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `cantidad` double NOT NULL,
  `unidad` varchar(50) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_estado`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurso_estado`
--

LOCK TABLES `recurso_estado` WRITE;
/*!40000 ALTER TABLE `recurso_estado` DISABLE KEYS */;
INSERT INTO `recurso_estado` VALUES (1,'M999.999.9469.00','VACUNA ANTIMARILICA',0,'DOSIS',' ',' '),(2,'SN-1','VACUNA CONTRA LA FIEBRE AMARILLA',1,'PAQ',' ',' '),(3,'D999.999.8850.00','CALDO SOYA TRIPTICASEINA 450GR',0,'PZA','',''),(4,'D999.999.8869.00','CALDO EC DE 500GR',0,'PZA','',''),(5,'D999.999.8894.00','CALDO RAPPAPORT VASILIADIS 500GR',0,'PZA','',''),(6,'100014936','ESTANDAR DE CONDUCTIVIDAD',0,'PAQ','',''),(8,'D999.999.8938.00','PLASMA DE CONEJO FRESCO',0,'PZA','',''),(9,'D999.999.8882.00','CAJA PETRI DES S/DIVISION 100 X 15MM ',0,'CJ','',''),(10,'D999.999.9472.00','FRASCO BOCA ANCHA 1LT',0,'PZA','','');
/*!40000 ALTER TABLE `recurso_estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vale_entrada`
--

DROP TABLE IF EXISTS `vale_entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vale_entrada` (
  `folio` varchar(20) NOT NULL,
  `fecha` date NOT NULL,
  `tabla` varchar(50) NOT NULL,
  `cargo` varchar(255) NOT NULL,
  `partida` varchar(255) NOT NULL,
  `programa` varchar(255) NOT NULL,
  `pedido` varchar(30) NOT NULL,
  `proveedor` varchar(255) NOT NULL,
  `fondo` varchar(255) NOT NULL,
  `factura` varchar(20) NOT NULL,
  `entrada` varchar(40) NOT NULL,
  `solicitado` varchar(255) NOT NULL,
  `director` varchar(255) NOT NULL,
  `autorizado` varchar(255) NOT NULL,
  `tipo` varchar(50) NOT NULL DEFAULT 'vale',
  `estado` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`folio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vale_entrada`
--

LOCK TABLES `vale_entrada` WRITE;
/*!40000 ALTER TABLE `vale_entrada` DISABLE KEYS */;
INSERT INTO `vale_entrada` VALUES ('43132','2020-06-23','papeleria','OFICINA CENTRAL ','ROBERTO DE LA FUENTE RETA ','COEPRIS','ROBERTO DE LA FUENTE RETA ','ROBERTO DE LA FUENTE RETA ','FASSA 2020','465612','107/2020','CP. GERARDO OSORNIO IMPERIAL','LIC. LAURA RAFAELA CABRERA LOZANO ','DR. OSCAR VILLA GARZA','vale',0);
/*!40000 ALTER TABLE `vale_entrada` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-12 12:27:03
